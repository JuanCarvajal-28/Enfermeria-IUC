// =====================================================
//  APP ENFERMERÍA ESCOLAR (FRONTEND PURO)
// -----------------------------------------------------
//  Este archivo contiene toda la lógica en JavaScript.
//  - Maneja el inicio de sesión de prueba
//  - Cambia entre las diferentes pantallas
//  - Simula una base de datos en memoria + localStorage
//  - Permite CRUD básico de estudiantes y registro de
//    medicamentos y consultas.
// =====================================================

// ------------------
// 1. "Base de datos"
// ------------------
// Aquí guardaremos los estudiantes y los medicamentos
// en arreglos. También los almacenamos en localStorage
// para que no se pierdan al recargar la página.

let estudiantes = [];   // Cada elemento será un objeto { id, nombre, sintomas, medicamento, remitido, fechaUltimaConsulta }
let medicamentos = [];  // Cada elemento será un objeto { estudiante, nombre, notas }

// Variable para recordar qué estudiante estamos editando
let estudianteEnEdicionId = null;

// Usuario "quemado" de prueba
const USUARIO_PRUEBA = {
    usuario: "juan jose",
    password: "Juanjo25*"
};

// Claves para localStorage
const STORAGE_KEYS = {
    estudiantes: "app_enfermeria_estudiantes",
    medicamentos: "app_enfermeria_medicamentos",
    usuario: "app_enfermeria_usuario"
};

// ---------------------------
// 2. Funciones de utilidades
// ---------------------------

/**
 * Muestra solo la pantalla indicada por su id.
 * Oculta todas las demás pantallas.
 * @param {string} idPantalla - El id de la sección que queremos mostrar.
 */
function mostrarPantalla(idPantalla) {
    const pantallas = document.querySelectorAll(".pantalla");
    pantallas.forEach((p) => p.classList.remove("pantalla-activa"));

    const pantalla = document.getElementById(idPantalla);
    if (pantalla) {
        pantalla.classList.add("pantalla-activa");
        window.scrollTo({ top: 0, behavior: "smooth" });
    }
}

/**
 * Carga la información guardada en localStorage
 * y la asigna a los arreglos en memoria.
 */
function cargarDesdeLocalStorage() {
    const datosEstudiantes = localStorage.getItem(STORAGE_KEYS.estudiantes);
    const datosMedicamentos = localStorage.getItem(STORAGE_KEYS.medicamentos);

    if (datosEstudiantes) {
        estudiantes = JSON.parse(datosEstudiantes);
    }

    if (datosMedicamentos) {
        medicamentos = JSON.parse(datosMedicamentos);
    }
}

/**
 * Guarda los arreglos de estudiantes y medicamentos en localStorage.
 */
function guardarEnLocalStorage() {
    localStorage.setItem(STORAGE_KEYS.estudiantes, JSON.stringify(estudiantes));
    localStorage.setItem(STORAGE_KEYS.medicamentos, JSON.stringify(medicamentos));
}

/**
 * Genera un id simple para un nuevo estudiante.
 * En una base de datos real esto lo haría el motor de BD.
 */
function generarIdEstudiante() {
    const ultimoId = estudiantes.length > 0 ? estudiantes[estudiantes.length - 1].id : 0;
    return ultimoId + 1;
}

/**
 * Devuelve un estudiante buscando por nombre (ignorando mayúsculas/minúsculas).
 * Si hay varios con el mismo nombre, devuelve el primero.
 */
function buscarEstudiantePorNombre(nombre) {
    const nombreNormalizado = nombre.trim().toLowerCase();
    return estudiantes.find((e) => e.nombre.toLowerCase() === nombreNormalizado) || null;
}

/**
 * Actualiza las tablas de listados (remitidos y medicamentos).
 * Se llama cada vez que hay cambios.
 */
function refrescarListados() {
    // Tabla de remitidos (pantalla "Fue remitido")
    const cuerpoRemitidos = document.getElementById("tabla-remitidos");
    if (cuerpoRemitidos) {
        cuerpoRemitidos.innerHTML = "";
        estudiantes.forEach((e) => {
            const tr = document.createElement("tr");

            const tdNombre = document.createElement("td");
            tdNombre.textContent = e.nombre;
            tr.appendChild(tdNombre);

            const tdFecha = document.createElement("td");
            tdFecha.textContent = e.fechaUltimaConsulta || "Sin registro";
            tr.appendChild(tdFecha);

            const tdRemitido = document.createElement("td");
            tdRemitido.textContent = e.remitido || "No aplica";
            tr.appendChild(tdRemitido);

            cuerpoRemitidos.appendChild(tr);
        });
    }

    // Tabla de medicamentos (pantalla "Medicamentos")
    const cuerpoMedicamentos = document.getElementById("tabla-medicamentos");
    if (cuerpoMedicamentos) {
        cuerpoMedicamentos.innerHTML = "";
        medicamentos.forEach((m) => {
            const tr = document.createElement("tr");

            const tdEstudiante = document.createElement("td");
            tdEstudiante.textContent = m.estudiante;
            tr.appendChild(tdEstudiante);

            const tdMedicamento = document.createElement("td");
            tdMedicamento.textContent = m.nombre;
            tr.appendChild(tdMedicamento);

            const tdNotas = document.createElement("td");
            tdNotas.textContent = m.notas || "";
            tr.appendChild(tdNotas);

            cuerpoMedicamentos.appendChild(tr);
        });
    }
}

// -------------------------
// 3. Inicio de la aplicación
// -------------------------

document.addEventListener("DOMContentLoaded", () => {
    // Cargar datos previos (si existen)
    cargarDesdeLocalStorage();
    refrescarListados();

    // ---------- MANEJO DE NAVEGACIÓN ----------
    // Botones con atributo data-ir cambian de pantalla
    document.body.addEventListener("click", (event) => {
        const boton = event.target.closest("[data-ir]");
        if (boton) {
            const destino = boton.getAttribute("data-ir");
            mostrarPantalla(destino);
        }
    });

    // Botón de cerrar sesión
    const btnCerrarSesion = document.getElementById("btn-cerrar-sesion");
    if (btnCerrarSesion) {
        btnCerrarSesion.addEventListener("click", () => {
            // Al cerrar sesión simplemente volvemos al login
            mostrarPantalla("pantalla-login");
        });
    }

    // ---------------------------
    // 3.1. Inicio de sesión
    // ---------------------------
    const formLogin = document.getElementById("form-login");
    const loginError = document.getElementById("login-error");

    formLogin.addEventListener("submit", (event) => {
        event.preventDefault();

        const usuario = document.getElementById("login-usuario").value.trim();
        const password = document.getElementById("login-password").value;

        const esUsuarioPrueba =
            usuario.toLowerCase() === USUARIO_PRUEBA.usuario &&
            password === USUARIO_PRUEBA.password;

        if (esUsuarioPrueba) {
            loginError.textContent = "";
            mostrarPantalla("pantalla-menu");
        } else {
            loginError.textContent = "Usuario o contraseña incorrectos. Inténtalo de nuevo.";
        }
    });

    // ---------------------------
    // 3.2. Registro (simulado)
    // ---------------------------
    const formRegistro = document.getElementById("form-registro");
    const registroMensaje = document.getElementById("registro-mensaje");

    formRegistro.addEventListener("submit", (event) => {
        event.preventDefault();

        const usuario = document.getElementById("registro-usuario").value.trim();
        const password = document.getElementById("registro-password").value;
        const password2 = document.getElementById("registro-password2").value;

        if (password !== password2) {
            registroMensaje.textContent = "Las contraseñas no coinciden.";
            return;
        }

        // Aquí solo guardamos el usuario en localStorage como ejemplo.
        const nuevoUsuario = { usuario, password };
        localStorage.setItem(STORAGE_KEYS.usuario, JSON.stringify(nuevoUsuario));

        registroMensaje.textContent =
            "Usuario registrado (simulado). Para la entrega se usará principalmente el usuario de prueba.";

        // Opcional: limpiar campos
        formRegistro.reset();
    });

    // ---------------------------
    // 3.3. Agregar estudiante
    // ---------------------------
    const formAgregar = document.getElementById("form-agregar-estudiante");
    const agregarMensaje = document.getElementById("agregar-mensaje");

    formAgregar.addEventListener("submit", (event) => {
        event.preventDefault();

        const nombre = document.getElementById("agregar-nombre").value.trim();
        const sintomas = document.getElementById("agregar-sintomas").value.trim();
        const medicamento = document.getElementById("agregar-medicamento").value.trim();

        const nuevoEstudiante = {
            id: generarIdEstudiante(),
            nombre,
            sintomas,
            medicamento,
            remitido: "No aplica",
            fechaUltimaConsulta: new Date().toLocaleDateString()
        };

        estudiantes.push(nuevoEstudiante);
        guardarEnLocalStorage();
        refrescarListados();

        agregarMensaje.textContent = "Estudiante guardado correctamente.";
        formAgregar.reset();
    });

    // ---------------------------
    // 3.4. Buscar y editar estudiante
    // ---------------------------
    const formBuscar = document.getElementById("form-buscar-estudiante");
    const buscarMensaje = document.getElementById("buscar-mensaje");
    const formEditar = document.getElementById("form-editar-estudiante");

    formBuscar.addEventListener("submit", (event) => {
        event.preventDefault();

        const nombreBuscado = document.getElementById("buscar-nombre").value.trim();
        const estudiante = buscarEstudiantePorNombre(nombreBuscado);

        if (!estudiante) {
            buscarMensaje.textContent = "No se encontró ningún estudiante con ese nombre.";
            formEditar.style.display = "none";
            estudianteEnEdicionId = null;
            return;
        }

        buscarMensaje.textContent = `Estudiante encontrado: ID ${estudiante.id}`;
        estudianteEnEdicionId = estudiante.id;

        // Llenamos el formulario de edición
        document.getElementById("editar-nombre").value = estudiante.nombre;
        document.getElementById("editar-sintomas").value = estudiante.sintomas;
        document.getElementById("editar-medicamento").value = estudiante.medicamento;
        document.getElementById("editar-remitido").value = estudiante.remitido || "No aplica";

        formEditar.style.display = "flex";
    });

    formEditar.addEventListener("submit", (event) => {
        event.preventDefault();
        if (estudianteEnEdicionId === null) return;

        const estudiante = estudiantes.find((e) => e.id === estudianteEnEdicionId);
        if (!estudiante) return;

        estudiante.nombre = document.getElementById("editar-nombre").value.trim();
        estudiante.sintomas = document.getElementById("editar-sintomas").value.trim();
        estudiante.medicamento = document.getElementById("editar-medicamento").value.trim();
        estudiante.remitido = document.getElementById("editar-remitido").value;

        guardarEnLocalStorage();
        refrescarListados();

        buscarMensaje.textContent = "Cambios guardados correctamente.";
    });

    // Botón para ir a la pantalla de eliminar
    const btnIrEliminar = document.getElementById("btn-ir-eliminar");
    btnIrEliminar.addEventListener("click", () => {
        if (estudianteEnEdicionId === null) return;
        mostrarPantalla("pantalla-eliminar");
    });

    // ---------------------------
    // 3.5. Eliminar estudiante
    // ---------------------------
    const btnConfirmarEliminar = document.getElementById("btn-confirmar-eliminar");
    const btnCancelarEliminar = document.getElementById("btn-cancelar-eliminar");
    const eliminarMensaje = document.getElementById("eliminar-mensaje");

    btnConfirmarEliminar.addEventListener("click", () => {
        if (estudianteEnEdicionId === null) {
            eliminarMensaje.textContent = "No hay estudiante seleccionado para eliminar.";
            return;
        }

        estudiantes = estudiantes.filter((e) => e.id !== estudianteEnEdicionId);
        estudianteEnEdicionId = null;

        guardarEnLocalStorage();
        refrescarListados();

        eliminarMensaje.textContent = "Estudiante eliminado correctamente.";
        // Volvemos a la pantalla de editar para que el usuario vea el cambio
        setTimeout(() => {
            eliminarMensaje.textContent = "";
            mostrarPantalla("pantalla-editar-buscar");
            const formEditar = document.getElementById("form-editar-estudiante");
            formEditar.style.display = "none";
        }, 1200);
    });

    btnCancelarEliminar.addEventListener("click", () => {
        eliminarMensaje.textContent = "";
        mostrarPantalla("pantalla-editar-buscar");
    });

    // ---------------------------
    // 3.6. Nueva consulta
    // ---------------------------
    const formNuevaConsulta = document.getElementById("form-nueva-consulta");
    const consultaMensaje = document.getElementById("consulta-mensaje");

    formNuevaConsulta.addEventListener("submit", (event) => {
        event.preventDefault();

        const nombre = document.getElementById("consulta-nombre").value.trim();
        const fecha = document.getElementById("consulta-fecha").value;
        const medicamentosTexto = document.getElementById("consulta-medicamentos").value.trim();
        const remitido = document.getElementById("consulta-remitido").value;
        const sintomas = document.getElementById("consulta-sintomas").value.trim();

        const estudiante = buscarEstudiantePorNombre(nombre);
        if (!estudiante) {
            consultaMensaje.textContent = "El estudiante no existe. Primero debes crearlo.";
            return;
        }

        // Actualizamos campos básicos del estudiante
        estudiante.fechaUltimaConsulta = fecha || new Date().toLocaleDateString();
        estudiante.medicamento = medicamentosTexto;
        estudiante.remitido = remitido;
        estudiante.sintomas = sintomas;

        guardarEnLocalStorage();
        refrescarListados();

        consultaMensaje.textContent = "Consulta registrada correctamente.";
        formNuevaConsulta.reset();
    });

    // ---------------------------
    // 3.7. Medicamentos
    // ---------------------------
    const formMedicamento = document.getElementById("form-medicamento");
    const medicamentoMensaje = document.getElementById("medicamento-mensaje");

    formMedicamento.addEventListener("submit", (event) => {
        event.preventDefault();

        const nombreEstudiante = document
            .getElementById("medicamento-nombre-estudiante")
            .value.trim();
        const nombreMedicamento = document.getElementById("medicamento-nombre").value.trim();
        const notas = document.getElementById("medicamento-notas").value.trim();

        if (!nombreEstudiante || !nombreMedicamento) {
            medicamentoMensaje.textContent = "Por favor completa los campos obligatorios.";
            return;
        }

        medicamentos.push({
            estudiante: nombreEstudiante,
            nombre: nombreMedicamento,
            notas
        });

        guardarEnLocalStorage();
        refrescarListados();

        medicamentoMensaje.textContent = "Medicamento registrado correctamente.";
        formMedicamento.reset();
    });
});
